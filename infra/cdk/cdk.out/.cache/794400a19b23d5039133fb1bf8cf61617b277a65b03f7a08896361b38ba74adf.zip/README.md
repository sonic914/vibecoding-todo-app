# backend

이 폴더는 VibeCoding TODO 웹앱의 백엔드(Node.js + TypeScript + AWS Lambda) 소스코드를 관리합니다.

- 주요 기술: Node.js, TypeScript, AWS Lambda, DynamoDB
- 테스트 및 인프라 연동 코드, 환경설정 파일 포함 예정
