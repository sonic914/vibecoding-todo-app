# Presentation Layer

This layer is responsible for handling user interaction and presenting data. In this project, it will contain the AWS Lambda handlers.
