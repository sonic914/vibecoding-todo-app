# Application Layer

This layer contains the application-specific business logic. It orchestrates the domain objects to perform specific use cases.
