# Domain Layer

This layer contains the enterprise-wide business logic and entities. It is the core of the application and is independent of other layers.
